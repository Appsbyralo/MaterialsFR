import SwiftUI

struct ViewC: View {
    /*#-code-walkthrough(5.1.modifier)*/
    @State private var color: Color = .blue
    /*#-code-walkthrough(5.1.modifier)*/
    var body: some View {
        
        ZStack {
            
            color
            
            VStack {
                Spacer() 
                
                Image(systemName: "questionmark.circle")
                    .foregroundColor(Color.white)
                    .font(.system(size: 100.0)) 
                
                Spacer() 
                /*#-code-walkthrough(5.2.modifier)*/
                ColorPicker("Color Picker", selection: $color)
                    .labelsHidden() 
                /*#-code-walkthrough(5.2.modifier)*/
                /*#-code-walkthrough(5.3.modifier)*/
                Label("Choisis une couleur", systemImage: "paintpalette")
                    .symbolVariant(.fill) 
                    .foregroundColor(.white)
                /*#-code-walkthrough(5.3.modifier)*/ 
                Spacer()
                /*#-code-walkthrough(5.4.modifier)*/
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.red, Color.orange, Color.yellow, Color.green, 
                                Color.blue, Color.indigo, Color.purple, Color.pink
                                /*#-code-walkthrough(5.4.modifier)*/
                            ]),
                            /*#-code-walkthrough(5.5.modifier)*/
                            startPoint: .leading,
                            endPoint: .trailing
                            /*#-code-walkthrough(5.5.modifier)*/
                        )
                    )
                    .frame(width: 400, height: 100)
                    .padding(.bottom, 50) 
                
            }
        }
    }
}

struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC()
    }
}

