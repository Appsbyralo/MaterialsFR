import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "phone.fill")
                    Text("ViewA Text")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "eraser.fill")
                    Text("ViewB Text")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("ViewC Text")
                }
            /*#-code-walkthrough(ViewD3.1)*/
            
            /*#-code-walkthrough(ViewD3.1)*/
        }
    }
}

