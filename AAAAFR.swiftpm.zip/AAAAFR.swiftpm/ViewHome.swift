import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. Une App sur les Apps\nC'est un processus de conception qui te guide de la génération d'idées à la création de prototypes d'apps, et finalement à une app complète. Ce bouton d'information te donne un aperçu du contenu de l'app.",
        "2. Dessiner\nSous l'onglet Dessiner, tu peux utiliser la boîte à outils intégrée pour faire des croquis et expliquer tes idées, ainsi que développer des mises en page. En cliquant sur 'Génération d'idées', tu peux dessiner 8 idées d'apps, parmi lesquelles tu pourras plus tard choisir la meilleure. Sous 'Vide', 'iPhone' et 'iPad', tu peux concevoir des mises en page pour ton app dans différents formats.",
        "3. Freeform\nEn cliquant sur Freeform, tu as la possibilité de télécharger une carte mentale dans Freeform, que tu peux utiliser pour connecter toutes tes idées liées à ton app. Dans la carte mentale, tu pourras glisser différents types de boutons, des cadres d'iPhone, et des post-it dans ton espace de travail. Si tu préfères, tu peux aussi créer une carte mentale traditionnelle sur papier.",
        "4. Matériaux\nSous Matériaux, tu as la possibilité de télécharger des ressources Keynote pour développer des prototypes pour ton app, que ce soit pour l'Apple Watch, l'iPhone, l'iPad ou le MacBook. Chaque thème Keynote est unique et propose une gamme de modèles pour tes mises en page. De plus, tu peux télécharger du matériel pédagogique pour le projet, ainsi que des activités pour les élèves. En outre, si tu le souhaites, tu peux télécharger des ressources pédagogiques spécifiques liées au codage en Swift.",
        "5. Apps\nSous l'onglet Apps, tu peux apprendre comment commencer à coder en Swift. Ici, tu peux explorer les ressources d'Apple, 'Get Started with Code' et 'About Me'. Unique à 'Une App sur les Apps', tu as la possibilité de télécharger 4 apps, où tu apprendras comment créer des barres de navigation (menus), des vues empilées (placement des objets), insérer du contenu (ajouter du texte, des images, des vidéos et des liens), et des éléments pour bien commencer (un mélange de diverses fonctions utiles pour ton app).",
        "6. Portfolio\nDans la section Portfolio, tu peux mettre à jour et documenter ton parcours, de l'idée au design, du feedback aux prototypes, jusqu'à l'app finale. Dans Portfolio, tu peux télécharger des photos de ta pellicule et décrire tes expériences avec du texte. Au bas du Portfolio, tu peux ajouter plus de cases pour les images et le texte."
    ]    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    
                    Text("Une App sur les Apps te guide de la création d'idées pour des apps nécessaires à la réalisation de croquis, à la description de ces idées, et à la création de prototypes d'apps. Si tu le souhaites, tu peux aussi apprendre à coder en Swift, pour éventuellement publier une vraie app sur l'App Store. Réalise tes visions et idées! Clique sur le bouton d'information pour obtenir un aperçu des différentes sections de l'app.")

                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Clique sur le bouton d'information pour obtenir un aperçu des différentes sections de l'app.")

                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Qu'est-ce qu'une App sur les Apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

