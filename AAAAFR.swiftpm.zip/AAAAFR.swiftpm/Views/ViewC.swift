import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Ici, tu peux télécharger la Boussole d'idées pour choisir ta meilleure idée. Tu peux aussi télécharger AppGPT, un chatbot pour développer ton idée d'app, une présentation One Pager pour présenter ton idée d'app, et une analyse de ton app préférée.",
        "2. App prototype iPad dans Keynote\nDans ce fichier Keynote, tu obtiens un thème Keynote adapté pour développer ton app prototype pour un iPad. En cliquant sur + pour ajouter une nouvelle diapositive, tu peux choisir parmi une gamme de mises en page pour exprimer au mieux tes idées.",
        "3. App prototype iPhone dans Keynote\nDans ce fichier Keynote, tu reçois un thème Keynote personnalisé pour développer ton app prototype pour un iPhone. En cliquant sur + pour ajouter une nouvelle diapositive, tu peux choisir parmi diverses mises en page pour communiquer efficacement tes idées.",
        "4. App prototype MacBook dans Keynote\nDans ce fichier Keynote, tu es fourni avec un thème Keynote spécialisé pour créer ton app prototype pour un MacBook. En appuyant sur + pour ajouter une nouvelle diapositive, tu peux choisir parmi différentes mises en page pour présenter clairement tes idées.",
        "5. App prototype Apple Watch dans Keynote\nDans ce fichier Keynote, tu reçois un thème Keynote unique pour concevoir ton app prototype pour une Apple Watch. En appuyant sur + pour insérer une nouvelle diapositive, tu peux choisir parmi une variété de mises en page pour transmettre tes idées efficacement.",
        "6. Matériaux pédagogiques\nDans les Matériaux pédagogiques, tu accèdes à des ressources qui t'aideront, en tant qu'enseignant, à lancer en toute confiance le projet 'Une App sur les Apps'. Tu peux télécharger un livre Keynote qui te guide à travers chaque facette, de l'idée à l'app prototype.",
        "7. Matériaux pédagogiques en Swift\nDe plus, tu peux télécharger un livre Keynote axé sur les premiers pas avec le codage en Swift et la facilitation des apps sous l'onglet 'Apps' dans ton enseignement.",
        "Créer un raccourci pour ton app",
        "1. Ouvre l'app Raccourcis sur ton iPad.",
        "2. Appuie sur le \"+\" pour créer un nouveau raccourci vers ton écran d'accueil.",
        "3. Recherche Keynote dans le champ de recherche. Maintenant, sélectionne le raccourci 'Lancer la présentation en mode Visionneuse'.",
        "4. Appuie sur la présentation Keynote pour sélectionner le fichier qui s'ouvrira lorsque tu appuieras sur le raccourci.",
        "5. Maintenant, appuie sur la flèche et nomme ton raccourci en appuyant sur 'Renommer', choisis une icône pour le raccourci, et enfin appuie sur 'Ajouter à l'écran d'accueil'.",
        "6. Appuie sur 'Ajouter' pour ajouter le raccourci à ton écran d'accueil.",
        "7. Tu as maintenant créé un raccourci sur ton écran d'accueil."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Crée un prototype avec des boutons de changement de page")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                   Text("Sur cette page, tu peux télécharger des matériaux pour les élèves pour analyser tes idées d'app et sélectionner la meilleure. De plus, tu peux télécharger des matériaux pour travailler sur ton app préférée, créer une présentation One Pager, et télécharger AppGPT, un chatbot qui challengera ton idée d'app. En outre, tu peux télécharger des fichiers de prototype d'app dans Keynote, conçus pour des apps sur iPad, iPhone, MacBook, et Apple Watch. En tant qu'enseignant, tu peux également télécharger des matériaux pédagogiques, y compris des ressources pour faciliter le projet d'enseignement et des matériaux visant à débuter avec le codage en Swift.")
                         
                        
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Student materials", description: "Click here to download the Idea Compass, AppGPT, My Favorite App and the One Pager presentation.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                       
                        contentBox(title: "App prototype iPad", description: "Click here to download the Keynote file for the iPad prototype. Develop your ideas seamlessly.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "App prototype iPhone", description: "Click here to download the Keynote file for the iPhone prototype. Bring your app ideas to life.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "App prototype Mac", description: "Click here to download the Keynote file for the Mac prototype. Design and refine your concepts.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "App prototype Apple Watch", description: "Click here to download the Keynote file for the Watch prototype. Innovate and visualize your app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                       
                        contentBox(title: "Teaching material", description: "An extensive guide to An App About Apps. Download Keynote books to help you get started and teach coding in Swift.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Teaching materals in Swift", description: "Additionally, you can download a Keynote book focused on getting started with coding in Swift and facilitating the apps under the 'apps' tab in your teaching.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                    .padding()
                }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
            Text("Qu'est-ce qu'une App sur les Apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
