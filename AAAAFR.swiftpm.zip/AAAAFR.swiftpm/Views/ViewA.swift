import SwiftUI

struct ViewANeumorphicStyle2: ButtonStyle {
    var isPressedStyle: Bool = false
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .padding(20)
            .foregroundColor(.white) 
            .background(
                Group {
                    if configuration.isPressed || isPressedStyle {
                        Capsule()
                            .fill(Color(.systemGray5))
                            .overlay(
                                Capsule()
                                    .stroke(Color.white, lineWidth: 4)
                                    .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                                    .shadow(color: Color.black.opacity(0.2), radius: 10, x: 5, y: 5)
                            )
                    } else {
                        Capsule()
                            .fill(Color(.systemGray6))
                            .shadow(color: Color.black.opacity(0.2), radius: 10, x: 5, y: 5)
                            .shadow(color: Color.white.opacity(0.7), radius: 10, x: -5, y: -5)
                    }
                }
            )
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .animation(.spring(), value: configuration.isPressed)
    }
}

struct ViewANeumorphicButton2: View {
    var title: String
    var imageName: String? = nil
    var action: () -> Void
    var isPressedStyle: Bool = false
    
    var body: some View {
        Button(action: action) {
            if let imageName = imageName {
                Label(title, systemImage: imageName)
                    .foregroundColor(.gray)
            } else {
                Text(title)
                    .foregroundColor(.gray)
            }
        }
        .buttonStyle(ViewANeumorphicStyle2(isPressedStyle: isPressedStyle))
    }
}

struct DrawingLine2 {
    var points: [CGPoint]
    var color: Color
}

struct CanvasDrawingExample: View {
    @State private var lines: [DrawingLine2] = []
    @State private var selectedColor = Color.orange
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    @State private var selectedButton: String? = "Standard Canvas"
    @State private var iPhoneScaleFactor: CGFloat = 0.70
    @State private var iPadScaleFactor: CGFloat = 0.7
    @State private var squaresScaleFactor: CGFloat = 0.95
    @State private var showClearConfirmationAlert = false 
    

    
    let images = [
        "draw1", "draw2", "draw3", "draw4", "draw5"
    ]
    
    @State private var imageTexts = [
        "1. Trousse à crayons\nEn haut de la page, tu trouveras ta trousse à crayons. Elle contient une gamme de couleurs – clique sur la couleur que tu veux, puis utilise ton doigt ou un Apple Pencil pour dessiner sur l'écran. Besoin d'effacer quelque chose? Sélectionne la gomme à gauche et passe ton doigt sur ce que tu veux enlever. Tu veux tout recommencer? Clique sur le crayon avec le signe moins pour effacer tous tes dessins.",
        "2. Génération d'idées\nSur cette page, tu développes tes premières idées pour ton app. Dans chacune des 8 cases, tu peux dessiner, illustrer et noter des mots-clés pour soutenir ton texte. Une fois que tu as illustré tes 8 idées, prends une capture d'écran et insère-la dans ton Portfolio, situé en bas à droite du menu de cette app.",
        "3. Toile\nIci, tu as la possibilité de dessiner et illustrer sur une toile vierge pour montrer et visualiser tes idées pour la mise en page, le contenu, et les fonctionnalités de ton app.",
        "4. iPhone\nIci, tu peux dessiner et illustrer ton idée d'app dans des cadres d'iPhone pour démontrer et donner un aperçu de tes idées pour la mise en page, le contenu, et les fonctionnalités de ton app.",
        "5. iPad\nIci, tu peux dessiner et illustrer ton idée d'app dans des cadres d'iPad pour démontrer et donner un aperçu de tes idées pour la mise en page, le contenu, et les fonctionnalités de ton app."
    ]
    
    enum CanvasMode {
        case standard, iPhone, iPad, squares
    }
    
    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)
            
            VStack {
                HStack {
                    ForEach([Color.green, .orange, .blue, .red, .pink, .black, .purple], id: \.self) { color in
                        colorButton(color: color)
                    }
                    eraserButton()
                    clearButton()
                }
                
                Canvas { ctx, size in
                    switch selectedButton {
                    case "iPhone":
                        drawIPhoneScaffold(ctx: ctx, size: size, scaleFactor: iPhoneScaleFactor)
                    case "iPad":
                        drawIPadScaffold(ctx: ctx, size: size, scaleFactor: iPadScaleFactor)
                    case "8 Squares":
                        drawSquaresScaffold(ctx: ctx, size: size, scaleFactor: squaresScaleFactor)
                    default:
                        break
                    }
                    
                    for line in lines {
                        var path = Path()
                        path.addLines(line.points)
                        
                        ctx.stroke(path, with: .color(line.color), style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                    }
                }
                .gesture(
                    DragGesture(minimumDistance: 0, coordinateSpace: .local)
                        .onChanged({ value in
                            let position = value.location
                            
                            if value.translation == .zero {
                                lines.append(DrawingLine2(points: [position], color: selectedColor))
                            } else {
                                guard let lastIdx = lines.indices.last else {
                                    return
                                }
                                
                                lines[lastIdx].points.append(position)
                            }
                        })
                )
                .padding(.bottom, 60)
            }
            
            VStack {
                Spacer()
                
                HStack {
                    Spacer()
                    
                    Button(action: {
                        showPopup.toggle()
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            VStack {
                Spacer()
                
                HStack(spacing: 10) {
                    
                    ViewANeumorphicButton2(title: "Génération d'idées", isPressedStyle: selectedButton == "8 Squares") {
                        selectedButton = "8 Squares"}
                    .frame(width: 160, height: 50)
                    .background(Color.white) 
                    
                    ViewANeumorphicButton2(title: "         Vide           ", isPressedStyle: selectedButton == "Blank") {
                        selectedButton = "Blank"
                        
                    }
                    .frame(width: 160, height: 50)
                    .background(Color.white) 
                    
                  
                    ViewANeumorphicButton2(title: "        iPhone        ", isPressedStyle: selectedButton == "iPhone") {
                        selectedButton = "iPhone"
                    }
                    .frame(width: 160, height: 50)
                    .background(Color.white) 
                    
                    
                    ViewANeumorphicButton2(title: "           iPad           ", isPressedStyle: selectedButton == "iPad") {
                        selectedButton = "iPad"
                    }
                    .frame(width: 160, height: 50)
                    .background(Color.white) 
                }
                .padding(.bottom, 20)
            }
            
            if showPopup {
                PopupView4(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let fullscreenImageIndex = fullscreenImageIndex {
                FullscreenImageView3(images: images, descriptions: imageTexts, currentIndex: fullscreenImageIndex, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    func colorButton(color: Color) -> some View {
        Button {
            selectedColor = color
        } label: {
            Image(systemName: "circle.fill")
                .font(.largeTitle)
                .foregroundColor(color)
                .mask {
                    Image(systemName: "pencil.tip")
                        .font(.largeTitle)
                }
        }
    }
    
    @ViewBuilder
    func eraserButton() -> some View {
        Button {
            selectedColor = .white
        } label: {
            Image(systemName: "eraser")
                .font(.largeTitle)
                .foregroundColor(.gray)
        }
    }
    
    @ViewBuilder
    func clearButton() -> some View {
        Button {
            showClearConfirmationAlert = true
        } label: {
            Image(systemName: "pencil.tip.crop.circle.badge.minus")
                .font(.largeTitle)
                .foregroundColor(.gray)
        }
        .alert(isPresented: $showClearConfirmationAlert) {
            Alert(
                title: Text("Es-tu sûr?"),
                message: Text("Es-tu sûr de vouloir tout effacer ce que tu as dessiné?"),
                primaryButton: .destructive(Text("Effacer")) {
                    lines = []
                },
                secondaryButton: .cancel()
            )
        }
    }
    
    func drawIPhoneScaffold(ctx: GraphicsContext, size: CGSize, scaleFactor: CGFloat) {
        let aspectRatio: CGFloat = 9 / 19.5
        let scaffoldWidth = min(size.width * scaleFactor, size.height * aspectRatio * scaleFactor)
        let scaffoldHeight = scaffoldWidth / aspectRatio
        
        let scaffoldRect1 = CGRect(x: (size.width - scaffoldWidth * 2 - 20) / 2, y: (size.height - scaffoldHeight) / 2, width: scaffoldWidth, height: scaffoldHeight)
        let scaffoldRect2 = CGRect(x: scaffoldRect1.maxX + 20, y: scaffoldRect1.minY, width: scaffoldWidth, height: scaffoldHeight)
        
        ctx.stroke(Path(roundedRect: scaffoldRect1, cornerRadius: 20), with: .color(.gray), style: StrokeStyle(lineWidth: 2))
        ctx.stroke(Path(roundedRect: scaffoldRect2, cornerRadius: 20), with: .color(.gray), style: StrokeStyle(lineWidth: 2))
    }
    
    func drawIPadScaffold(ctx: GraphicsContext, size: CGSize, scaleFactor: CGFloat) {
        let aspectRatio: CGFloat = 4 / 3
        let scaffoldWidth = min(size.width * scaleFactor, size.height * aspectRatio * scaleFactor)
        let scaffoldHeight = scaffoldWidth / aspectRatio
        
        let scaffoldRect1 = CGRect(x: (size.width - scaffoldWidth) / 2, y: (size.height - scaffoldHeight) / 2, width: scaffoldWidth, height: scaffoldHeight)
        
        ctx.stroke(Path(roundedRect: scaffoldRect1, cornerRadius: 20), with: .color(.gray), style: StrokeStyle(lineWidth: 2))
    }
    
    func drawSquaresScaffold(ctx: GraphicsContext, size: CGSize, scaleFactor: CGFloat) {
        let rows = 2
        let cols = 4
        let padding: CGFloat = 10
        let totalPaddingH = padding * CGFloat(cols + 1)
        let totalPaddingV = padding * CGFloat(rows + 1)
        let squareSize = min((size.width * scaleFactor - totalPaddingH) / CGFloat(cols), (size.height * scaleFactor - totalPaddingV) / CGFloat(rows))
        
        for row in 0..<rows {
            for col in 0..<cols {
                let x = (size.width - squareSize * CGFloat(cols) - totalPaddingH) / 2 + CGFloat(col) * (squareSize + padding) + padding
                let y = (size.height - squareSize * CGFloat(rows) - totalPaddingV) / 2 + CGFloat(row) * (squareSize + padding) + padding
                let squareRect = CGRect(x: x, y: y, width: squareSize, height: squareSize)
                
                ctx.stroke(Path(roundedRect: squareRect, cornerRadius: 5), with: .color(.gray), style: StrokeStyle(lineWidth: 2))
            }
        }
    }
    

    
   
    }



struct FullscreenImageView3: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                    .padding()
                                    .foregroundColor(.black) 
                                    .multilineTextAlignment(.center) 
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Spacer()
            }
        }
    }
}


struct PopupView4: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @Binding var fullscreenImageIndex: Int?
    @State private var currentPage: Int = 0
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Qu'est-ce qu'une App sur les Apps?")
                .font(.headline)
                .foregroundColor(.black) 
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                withAnimation {
                                    fullscreenImageIndex = index
                                }
                            }
                        
                        ScrollView {
                            Text(imageTexts[index])
                                .font(.body)
                                .multilineTextAlignment(.center) // Centering the text
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                .frame(maxWidth: .infinity, alignment: .center) // Centering the text
                                .foregroundColor(.black) // Added foreground color
                        }
                        .frame(height: 150)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            VStack {
                Text("\(currentPage + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(5)
                
                Button(action: {
                    showPopup = false
                }) {
                    Image(systemName: "xmark.circle")
                        .font(.title2)
                        .padding()
                        .foregroundColor(.black)
                        .cornerRadius(10)
                }
                .padding(.top, 5)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}

struct ViewA: View {
    var body: some View {
        CanvasDrawingExample()
    }
}

struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}

