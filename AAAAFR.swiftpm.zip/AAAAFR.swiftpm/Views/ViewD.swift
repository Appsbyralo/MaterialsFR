import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("Apps que tu peux utiliser comme blocs de construction et source d'inspiration")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("Sur cette page, tu dois décrire ce qui doit être inclus dans ton app, comment elle doit être conçue, et pourquoi. Ce travail doit être compilé dans un document tableau blanc dans Freeform. Nous avons créé un modèle pour toi. Tu peux le télécharger en appuyant sur l'icône de l'app Freeform ci-dessous. Une fois que tu as téléchargé le document, tu dois le dupliquer. Apprends comment en cliquant sur le bouton d'information sur cette page.")

                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10) 
                        .minimumScaleFactor(0.5) 
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Commencer avec le code", description: "Un excellent point de départ pour débuter ton voyage en programmation.", linkURL: "")
                        
                        contentBox(title: "À propos de moi", description: "Crée un projet sur toi-même et apprends à coder tout en construisant ta première app.", linkURL: "")
                        
                        contentBox(title: "Créer une barre de navigation", description: "Apprends à créer un menu avec trois boutons—ou autant que tu veux. Cette app est incluse dans ton abonnement à 'Une App sur les Apps' sur la page d'accueil de Swift. Fais défiler vers le bas et trouve l'app Barre de Navigation.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Vues empilées", description: "Apprends à positionner des objets horizontalement, verticalement, et le long de l'axe Z—ou combine les différentes options. Cette app est incluse dans ton abonnement à 'Une App sur les Apps' sur la page d'accueil de Swift. Fais défiler vers le bas et trouve l'app Vues empilées.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Insérer du contenu", description: "Apprends à ajouter des photos, vidéos et liens à ton app. Cette app est incluse dans ton abonnement à 'Une App sur les Apps' sur la page d'accueil de Swift. Fais défiler vers le bas et trouve l'app Insérer du contenu.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "Éléments pour bien commencer", description: "C'est une app avec diverses idées—comme des cartes GPS d'Apple Maps et différents types de boutons qui ensemble peuvent rendre ton app unique. Cette app est incluse dans ton abonnement à 'Une App sur les Apps' sur la page d'accueil de Swift. Fais défiler vers le bas et trouve l'app Éléments pour bien commencer.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

