import SwiftUI

struct ViewC: View {
    // State for the toggle switch and slider
    @State private var isOn: Bool = false
    @State private var sliderValue: Double = 50
    
    var body: some View {
        
        VStack {
               
            LazyVGrid(columns: [GridItem(.flexible())], spacing: 40) {
                
                // Square Button with text "Button 1"
                Button("Button 1") {
                    // Action for Button 1
                    print("Button 1 pressed")
                }
                .padding() // Add space inside the button
                .frame(width: 300, height: 100) // Size of the button
                .background(Color.blue) // Button color
                .foregroundColor(.white) // Text color
                .font(.title) 
                .cornerRadius(10) // Rounded corners
                .border(Color.black, width: 1) // Border around the button
                
                // Oblong Button with rounded edges and text "Button 2"
                Button("Button 2") {
                    // Action for Button 2
                    print("Button 2 pressed")
                }
                .padding()
                .frame(width: 400, height: 100) 
                .background(Color.green)
                .foregroundColor(.white)
                .font(.title) 
                .cornerRadius(50) 
                
                // Round Button with an airplane symbol
                Button(action: {
                    // Action for Button 3
                    print("Button 3 pressed")
                }) {
                    Image(systemName: "airplane") // Airplane icon
                        .font(.largeTitle)
                }
                .padding()
                .frame(width: 100, height: 100) // Size of the button
                .background(Color.orange)
                .foregroundColor(.white)
                .clipShape(Circle()) // Make the button round
                
                // Button like Button 2 with both symbol and text
                Button(action: {
                    // Action for Button 4
                    print("Button 4 pressed")
                }) {
                    HStack {
                        Image(systemName: "star.fill") // Star icon
                        Text("Button 4")
                    }
                }
                .padding()
                .frame(width: 400, height: 100) // Size of the button
                .background(Color.purple)
                .foregroundColor(.white)
                .font(.title)
                .cornerRadius(50)
                
                // Toggle switch with text "ON" or "OFF"
                HStack {
                    Spacer() // Add spacing to the left
                    Text(isOn ? "ON" : "OFF") // Show "ON" or "OFF" based on toggle state
                        .font(.title)
                        .lineLimit(1) // Ensure text stays on one line
                    Spacer().frame(width: 10) // Add space between text and toggle
                    Toggle("", isOn: $isOn) // Empty label to remove the default text
                        .toggleStyle(SwitchToggleStyle(tint: .gray))
                        .frame(width: 100) 
                    Spacer() // Add spacing to the right
                }
                .padding()
                .frame(width: 300, height: 100)
                .background(Color.yellow)
                .cornerRadius(50)
                .foregroundColor(.black)
         
                    Slider(value: $sliderValue, in: 0...100)
                        .padding()
                        .frame(width: 400, height: 100)
                        .tint(.blue) // Sets the color of the slider line
                        .scaleEffect(x: 1, y: 2) // Thickness slider line
                }
            }
        }
    
}

struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC()
    }
}
