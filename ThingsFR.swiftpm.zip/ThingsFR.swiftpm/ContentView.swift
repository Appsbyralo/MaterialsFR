import SwiftUI


struct ContentView: View {
    var body: some View {
        
        TabView {
            ViewHome()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            ViewA()
                .tabItem() {
                    Image(systemName: "airplane.circle")
                    Text("Text A")
                }
            
            ViewB()
                .tabItem() {
                    Image(systemName: "house.circle")
                    Text("Text B")
                }
            
            ViewC()
                .tabItem() {
                    Image(systemName: "questionmark.circle")
                    Text("Text C")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
