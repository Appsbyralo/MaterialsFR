import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "phone.fill")
                    Text("Inserisci foto")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "eraser.fill")
                    Text("Inserisci link")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Inserisci video")
                }
            ViewD()
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Scroll View")
                }
        }
    }
}




