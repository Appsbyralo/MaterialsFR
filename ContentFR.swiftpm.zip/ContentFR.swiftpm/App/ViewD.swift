import SwiftUI

struct ViewD: View {
    var body: some View {
        GeometryReader { geometry in
            /*#-code-walkthrough(VD.2.2)*/
            let imageSize = geometry.size.width / 3.65
            /*#-code-walkthrough(VD.2.2)*/
            
            /*#-code-walkthrough(VD.2)*/
            ScrollView {
                VStack(spacing: 20) {
                    /*#-code-walkthrough(VD.2.3)*/
                    Image("Image1")
                        .resizable()
                        .aspectRatio(16/9, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                    /*#-code-walkthrough(VD.2.3)*/
                    
                    /*#-code-walkthrough(VD.3)*/
                    Image("Image2")
                        .resizable()
                        .frame(width: 600, height: 337.5)
                    /*#-code-walkthrough(VD.3)*/
                    
                    /*#-code-walkthrough(VD.4)*/
                    Image("Image3")
                        .resizable()
                        .aspectRatio(16/9, contentMode: .fit)
                        .frame(width: 600)
                    /*#-code-walkthrough(VD.4)*/
                }
            }
            /*#-code-walkthrough(VD.2)*/
        }
    }
}

struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}


