import SwiftUI

struct ViewA: View {
    var body: some View {
       
        VStack {
            Text("📒")
                .font(.system(size: 148))
            Text("🍔")
                .font(.system(size: 148))
        }
    }
}


struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}

